# Ledger — Personal Finance Advisor Bot

A conversational AI personal finance advisor built as a course capstone project.

## Live Demo

**[Try Ledger here](https://claude.ai/artifact/QHZMAkUYt6eG8BcLX9fTwU)**

## What it does

- Tracks monthly income and categorized expenses through natural conversation
- Maintains a live ledger-style summary: income, total expenses, balance, savings rate
- Breaks down spending by category (Food, Transport, Education, Shopping, Entertainment, Rent/Hostel, Bills, Healthcare, Travel, Other)
- Helps set and track savings goals, with an estimated required monthly saving amount
- Generates a plain-text monthly financial report on request
- Offers grounded, non-judgmental suggestions — never invents financial data, never guarantees investment returns, and points users to a qualified professional for loans/tax/insurance decisions

## How it works

Ledger is a single self-contained HTML page (`index.html`). It runs entirely in the browser and calls Claude to generate responses and extract structured data (income, expense updates, savings goals) from each message, which it uses to update the on-page summary in real time. Conversation data is saved to the browser's local storage, so it persists between visits on the same device.

## Tech

- Vanilla HTML / CSS / JavaScript — no build step, no dependencies
- Claude (Anthropic) for natural-language understanding and reply generation
- Responsive layout (desktop + mobile)

## Files

- `index.html` — the full application

## Note

This project is for educational purposes. It provides general budgeting guidance, not professional financial advice.
